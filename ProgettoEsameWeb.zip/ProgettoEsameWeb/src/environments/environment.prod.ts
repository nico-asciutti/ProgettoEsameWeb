export const environment = {
  firebase: {
    projectId: 'progettoesameweb',
    appId: '1:987599789028:web:8e98f787afdc7e42f445f1',
    databaseURL: 'https://progettoesameweb-default-rtdb.firebaseio.com',
    storageBucket: 'progettoesameweb.appspot.com',
    apiKey: 'AIzaSyCADi0awsGb6ioJrnEJJJqTc7W4buh4Ra0',
    authDomain: 'progettoesameweb.firebaseapp.com',
    messagingSenderId: '987599789028',
    measurementId: 'G-LV1B65807P',
  },
  production: true
};
