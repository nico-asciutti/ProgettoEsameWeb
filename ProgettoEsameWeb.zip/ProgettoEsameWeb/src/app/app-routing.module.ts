import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { DoveSiamoComponent } from './dove-siamo/dove-siamo.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { PrenotaComponent } from './prenota/prenota.component';

const routes: Routes = [
  {path: ' ', component: AppComponent},
  {path: 'menu', component: MenuComponent},
  {path: 'dove-siamo', component: DoveSiamoComponent},
  {path: 'prenota', component: PrenotaComponent},
  {path: 'login', component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [MenuComponent, DoveSiamoComponent, PrenotaComponent, LoginComponent]