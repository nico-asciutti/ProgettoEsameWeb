import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dove-siamo',
  templateUrl: './dove-siamo.component.html',
  styleUrls: ['./dove-siamo.component.css']
})
export class DoveSiamoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
