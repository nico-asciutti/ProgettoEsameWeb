import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Lo Varchetto';

  expanded = false;

  setExpanded() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      this.expanded = false;
    }
  }

  NotExpanded() {
    if (this.expanded) {
      this.expanded = false;
    }
  }
 
}
